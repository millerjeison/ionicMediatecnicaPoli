import { Filter2Pipe } from './filter2.pipe';

describe('Filter2Pipe', () => {
  it('create an instance', () => {
    const pipe = new Filter2Pipe();
    expect(pipe).toBeTruthy();
  });
});
