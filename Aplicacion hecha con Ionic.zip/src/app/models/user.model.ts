

export interface Usurio {
  total_count: number;
  incomplete_results: boolean;

}
